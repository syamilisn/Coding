# run

MAIN:
script.sh
headers.h
template.c
git.sh

CMD:
./script.sh filename desc

